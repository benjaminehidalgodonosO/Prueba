def mostrar_menu():
    print("\n========== MENÚ PRINCIPAL ==========")
    print("1.Agregar producto")
    print("2.Buscar producto")
    print("3.Eliminar producto")
    print("4.Actualizar disponibilidad")
    print("5.Mostrar productos")
    print("6.Salir")
    print("\n====================================")

def leer_opcion():
    while True:
        try:
            opcion=int(input("Ingrese una opcion del 1 a 6:"))
            if 1<=opcion<=6:
                return opcion
            else:
                print("error ingrese un caracter numerico")
        except ValueError:
            print("error ingrese un numero del 1 al 6")
def Validar_nombre(nombre):
    return nombre.strip()!=""

def validar_stock(Stokc):
    return Stokc>0

def validar_precio(precio):
    return precio>0

def agregar_producto(lista_producto):
    nombre=input("ingrese el produco a comprar:")
    if not Validar_nombre(nombre):
        print("Error No puede aver espacios en vacios")
        return
    try:
        Stokc=int(input("Ingrese la cantidad a comprar:"))
    except ValueError:
        print("Error solo ingrese numeros enteros")
        return
    if not validar_stock(Stokc):
        print("error ingrese un numero positivo o mayor a 0")
        return
    try:
        precio=float(input("ingrese el precio del producto:"))
    except:
        print("error Ingrese solo numeros decimales")
        return
    if not validar_precio(precio):
        print("Error: Ingrese un numero mayor a 0")
        return
    Producto={
        "nombre":nombre,
        "stock":Stokc,
        "precio":precio,
        "precio":False
    }
    lista_producto.append(Producto)
    print("Producto agregado correctamente")

def Buscar_producto(lista_producto,nombre_buscar):
    for posicion in range(len(lista_producto)):
        if lista_producto[posicion]["nombre"]==nombre_buscar:
            return
        return -1

def eliminar_producto(lista_producto):
    Nombre_eliminar=input("ingrese el nombre del producto a eliminar:")
    posicion=Buscar_producto(lista_producto,Nombre_eliminar)
    if posicion !=-1:
        del lista_producto[posicion]
        print("El producto a sido eliminado")
    else:
        print(f"El producto {Nombre_eliminar} no se encuentra registrado.")

def Actualizar_disponibilidad(lista_producto):
    for Producto in lista_producto:
        if Producto [validar_stock]>=18:
            Producto["Disponible"]=True
        else:
            Producto["Disponible"]=False

def Mostrar_productos(lista_producto):
    Actualizar_disponibilidad(lista_producto)
    if len(lista_producto)==0:
        print("no hay stock")
        return
    print("\nLISTA DE PRODUCTOS")
    for producto in productos:
        if producto["Disponible"]:
            estado_texto="Disponible"
        else:
            estado_texto="No disponible"
            print(f"nombre:{producto}[nombre]")
            print(f"Stock:{producto}[Stock]")
            print(f"Precio:{producto}[precio]")
            print(f"Estado:{estado_texto}")
            print(f"*"*45)

productos=[]
while True:
    mostrar_menu()
    opcion=leer_opcion()

    if opcion==1:
        agregar_producto(productos)

    elif opcion==2:
        nombre_buscar=input("ingrese el nombre del producto:")
        
        posicion_encontrada=Buscar_producto(productos,nombre_buscar)
       
        if posicion_encontrada !=-1:
           
            producto = productos[posicion_encontrada]
         
            print("\n=========PRODUCTO ENCONTRADO=====")
            print("posicion:",posicion_encontrada)
            print("Nombre del producto:",producto[nombre])
            print("Stock:",producto[tock])
            print("Precio:",producto[precio])
            print("disponibilidad:",producto[activo])
        else:
            print("No Existe registro de este producto")

    elif opcion==3:
        eliminar_producto(productos)
    
    elif opcion==4:
        Actualizar_disponibilidad(productos)
        print("Se actualizo la lista")
    
    elif opcion==5:
        Mostrar_productos(productos)

    elif opcion==6:
        print("“Gracias por usar el sistema. Vuelva Pronto”")
        break






